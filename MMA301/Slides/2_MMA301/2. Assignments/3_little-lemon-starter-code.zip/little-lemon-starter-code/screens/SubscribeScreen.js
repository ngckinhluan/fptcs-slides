import * as React from 'react';
import { View } from 'react-native';

const SubscribeScreen = () => {
  // Add subscribe screen code here
  return <View></View>;
};

export default SubscribeScreen;
