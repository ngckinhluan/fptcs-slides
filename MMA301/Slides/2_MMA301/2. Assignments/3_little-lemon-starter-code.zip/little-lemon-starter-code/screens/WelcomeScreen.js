import * as React from 'react';
import { View } from 'react-native';

const WelcomeScreen = ({ navigation }) => {
  // Add welcome screen code here.
  return <View></View>;
};

export default WelcomeScreen;
